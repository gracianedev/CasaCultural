package com.casacultural.filme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmeApplicationTests {

	@Test
	void contextLoads() {
	}

}
